import React , {useEffect , useState} from 'react';
import './App.scss';
import 'antd/dist/antd.css';
import './theme/antd.scss'
import {Row ,Col , Typography, Button} from 'antd'
import {toPng} from 'html-to-image'
 

const {Text} = Typography

function App(){

  const [primaryColor , setPrimaryColor] = useState('#ca893f');
  const [secondaryColor , setSecondaryColor] = useState('#f0e760');
  const [backgroundColor , setBackgroundColor] = useState('#ffffff');
  const [selectHat , setSleectHat] = useState(0);
  const [cigarette , setCigarette] = useState(0);

  const [primaryColors , setPrimaryColors] = useState([]);
  const [secondaryColors , setSecondaryColors] = useState([]);
  const [backgroundColors , setBackgroundColors] = useState([]);
  const [hats , setHats] = useState([ 0 , 1 , 2 , 3]);
  const [cigarettes , setCigarettes] = useState([0 , 1]);



  useEffect(()=>{
    let root = document.documentElement;
    let pColor = hexToRgb(primaryColor);
    let sColor = hexToRgb(secondaryColor);
    
    pColor = `${pColor[0]},${pColor[1]},${pColor[2]}`
    sColor = `${sColor[0]},${sColor[1]},${sColor[2]}`

    root.style.setProperty("--image-primary-color", pColor);
    root.style.setProperty("--image-secondary-color", sColor);
    root.style.setProperty("--image-background-color", backgroundColor);
  },[primaryColor , secondaryColor , backgroundColor])



  const hexToRgb = hex =>
    hex.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i
             ,(m, r, g, b) => '#' + r + r + g + g + b + b)
    .substring(1).match(/.{2}/g)
    .map(x => parseInt(x, 16))

  const sleep = (ms) => {
      return new Promise(resolve => setTimeout(resolve, ms));
  }



  const generate = async ()=>{
    const images = document.getElementById('images');
    let root = document.documentElement;

    for(let c = 0 ; c < cigarettes.length ; c++){  // cigarettes
      for(let h = 0 ; h < hats.length ; h++){      // hat
        for(let b = 0 ; b < backgroundColors.length ; b++){      // backgorud color
          for(let p = 0 ; p < primaryColors.length ; p++){       // primary color
            for(let s = 0 ; s < secondaryColors.length ; s++){   // secondary color
    
                let background = backgroundColors[b];
                let primary = primaryColors[p];
                let secondary = secondaryColors[s];
                
                images.innerHTML = '';
                let pColor = hexToRgb(primary);
                let sColor = hexToRgb(secondary);
                
                pColor = `${pColor[0]},${pColor[1]},${pColor[2]}`
                sColor = `${sColor[0]},${sColor[1]},${sColor[2]}`
        
                root.style.setProperty("--image-primary-color", pColor);
                root.style.setProperty("--image-secondary-color", sColor);
                root.style.setProperty("--image-background-color", background);
    
                const imageBox = document.createElement('div');
                const image = document.createElement('div');
                const hat = document.createElement('div');
                const cig = document.createElement('div');

                imageBox.id = 'image-box'
                imageBox.className = 'image-box';
                image.className = 'image';
                hat.className = `hat-${hats[h]}`;
                cig.className = `cig-${hats[c]}`;

                imageBox.appendChild(image);
                imageBox.appendChild(hat);
                imageBox.appendChild(cig);
                images.appendChild(imageBox);
                download()
                await sleep(500);
    
            }
          }
        }
      }
    }


  }

  const download = ()=>{
    toPng(document.getElementById('image-box')).then(dataUrl => {
      const link = document.createElement('a');
      link.download = 'image.png';
      link.href = dataUrl;
      link.click();
    });
  }

  return(
    <div className={'App'}>


      <Row justify={'space-between'} className={'header-box'} align={'middle'} >
        <Col md={{span: 22}} className={'title-box'}>
          <Text className={'title'}>Crypto Zoo - Pixel Art</Text>
        </Col>
        <Col className={'icon-box'}>
           <i className="lab la-github icon"></i>
        </Col>
      </Row>


      <Row justify={'space-around'} align={'top'}>
        <Col md={{span: 4}}  className={'select-color-box'}>

          <Row align={'middle'} justify={'space-around'} >
            <Text className={'title'}>Primary Color</Text>
            <input type="color" className={'input'} value={primaryColor}  onChange={(e)=>{
                setPrimaryColor(e.target.value);
              }}/>
          </Row>
          <Row justify={'center'}>
            <Col md={{span: 18}}>
                <Button  className={'add-btn'} type={'primary'} block onClick={()=>{
                  setPrimaryColors([...primaryColors , primaryColor]);
                  setPrimaryColor('#ca893f');
                }} >Add Color</Button>
            </Col>
          </Row>
          <Row align={'middle'} justify={'center'} className={'colors-box'}>
            {primaryColors.map((color , index)=>{
                return(
                  <Col md={{span: 5}} key={index}
                    className={`color ${color === primaryColor ? 'active': ''}`}
                    style={{backgroundColor:color , height: '32px' , width: '100%'}}
                    onClick={()=>{
                      setPrimaryColor(color)
                    }}
                  >
                    <i className="las la-times icon" onClick={()=>{
                      let colors = [...primaryColors];
                      colors.splice(index , 1);
                      setPrimaryColors(colors);
                    }}></i>
                  </Col>
                )
              })}
          </Row>
        </Col>
        <Col md={{span: 4}}  className={'select-color-box'}>

            <Row align={'middle'} justify={'space-around'} >
              <Text className={'title'}>Secondary Color</Text>
              <input type="color" className={'input'} value={secondaryColor}  onChange={(e)=>{
                  setSecondaryColor(e.target.value);
                }}/>
            </Row>
            <Row justify={'center'}>
              <Col md={{span: 18}}>
                  <Button  className={'add-btn'} type={'primary'} block onClick={()=>{
                    setSecondaryColors([...secondaryColors , secondaryColor]);
                    setSecondaryColor('#f0e760');
                  }} >Add Color</Button>
              </Col>
            </Row>
            <Row align={'middle'} justify={'center'} className={'colors-box'}>
              {secondaryColors.map((color , index)=>{
                  return(
                    <Col md={{span: 5}} key={index}
                      className={`color ${color === secondaryColor ? 'active': ''}`}
                      style={{backgroundColor:color , height: '32px' , width: '100%'}}
                      onClick={()=>{
                        setSecondaryColor(color)
                      }}
                    >
                      <i className="las la-times icon" onClick={()=>{
                        let colors = [...secondaryColors];
                        colors.splice(index , 1);
                        setSecondaryColors(colors);
                      }}></i>
                    </Col>
                  )
                })}
            </Row>
          </Col>
        <Col md={{span: 4}}  className={'select-color-box'}>
            <Row align={'middle'} justify={'space-around'} >
              <Text className={'title'}>Background Color</Text>
              <input type="color" className={'input'} value={backgroundColor}  onChange={(e)=>{
                  setBackgroundColor(e.target.value);
                }}/>
            </Row>
            <Row justify={'center'}>
              <Col md={{span: 18}}>
                  <Button  className={'add-btn'} type={'primary'} block onClick={()=>{
                    setBackgroundColors([...backgroundColors , backgroundColor]);
                    setBackgroundColor('#ffffff');
                  }} >Add Color</Button>
              </Col>
            </Row>
            <Row align={'middle'} justify={'center'} className={'colors-box'}>
              {backgroundColors.map((color , index)=>{
                  return(
                    <Col md={{span: 5}} key={index}
                      className={`color ${color === backgroundColor ? 'active': ''}`}
                      style={{backgroundColor:color , height: '32px' , width: '100%'}}
                      onClick={()=>{
                        setBackgroundColor(color)
                      }}
                    >
                      <i className="las la-times icon" onClick={()=>{
                        let colors = [...backgroundColors];
                        colors.splice(index , 1);
                        setBackgroundColors(colors);
                      }}></i>
                    </Col>
                  )
                })}
            </Row>
        </Col>
        <Col md={{span: 4}} className={'options-box'} >
          <Row justify={'center'}>
            <Text className={'title'}>Options</Text>
          </Row>
        </Col>
                
      </Row>


      <Row className={'images'} id={'images'}>
        <div className={'image-box'}>
          <div className={'image'}></div>
        </div>
      </Row>


      <Row justify={'center'}>
          <Col md={{span: 5}} className={'generate-btn-box'}>
              <Button onClick={generate} type={'primary'} block>Generate</Button>
          </Col>
      </Row>

      


      {/* <Button onClick={generate}>generate</Button> */}




    </div>
  )
}



export default App;